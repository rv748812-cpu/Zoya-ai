import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import { createClient } from "@supabase/supabase-js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Supabase Setup
const supabaseUrl = process.env.SUPABASE_URL || "";
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY || "";
const supabase = createClient(supabaseUrl, supabaseAnonKey);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/memories", async (req, res) => {
    try {
      const { data, error } = await supabase
        .from("memories")
        .select("*");
      
      if (error) throw error;
      res.json(data || []);
    } catch (error) {
      console.error("Supabase fetch error:", error);
      res.status(500).json({ error: "Failed to fetch memories" });
    }
  });

  app.post("/api/memories", async (req, res) => {
    const { key, value } = req.body;
    if (!key || !value) {
      return res.status(400).json({ error: "Key and value are required" });
    }
    try {
      const { error } = await supabase
        .from("memories")
        .upsert({ key, value }, { onConflict: "key" });
      
      if (error) throw error;
      res.json({ success: true });
    } catch (error) {
      console.error("Supabase save error:", error);
      res.status(500).json({ error: "Failed to save memory" });
    }
  });

  app.delete("/api/memories/:key", async (req, res) => {
    const { key } = req.params;
    try {
      const { error } = await supabase
        .from("memories")
        .delete()
        .eq("key", key);
      
      if (error) throw error;
      res.json({ success: true });
    } catch (error) {
      console.error("Supabase delete error:", error);
      res.status(500).json({ error: "Failed to delete memory" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
