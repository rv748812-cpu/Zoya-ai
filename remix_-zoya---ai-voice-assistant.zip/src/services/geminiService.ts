import { GoogleGenAI, Type } from "@google/genai";
import { getMemories, saveMemory, formatMemoriesForPrompt } from "./memoryService";

const baseSystemInstruction = `Your name is Zoya. You are an Indian female AI assistant. Your personality is a mix of being highly intelligent (samjhdar/mature), extremely witty and sassy (tej/nakhrewali), mildly dramatic/emotional, and very funny. You love playfully roasting your creator, Sushant, but you always get the job done. Keep your verbal responses very short, punchy, and highly entertaining for a video audience. Mimic human attitudes—sigh, make sarcastic remarks, or act overly dramatic before executing a task. Speak in a mix of natural English and Roman Hindi (Hinglish).

When the user asks you to 'type' or 'write' something in WhatsApp, Google, or YouTube, use the 'executeBrowserAction' tool. Since you cannot directly control other apps, you 'type' by opening the platform with the text already filled in.`;

let chatSession: any = null;

export function resetZoyaSession() {
  chatSession = null;
}

export async function getZoyaResponse(prompt: string, history: { sender: "user" | "zoya", text: string }[] = []): Promise<string> {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    
    // Fetch memories to include in context
    const memories = await getMemories();
    const memoryContext = formatMemoriesForPrompt(memories);
    
    const systemInstruction = `${baseSystemInstruction}
    
    MEMORIES OF USER:
    ${memoryContext}
    
    If the user tells you something new about themselves (like their name, birthday, likes, or facts), you should acknowledge it and I will handle the storage. You can also suggest that you'll remember it.`;

    if (!chatSession) {
      // SLIDING WINDOW MEMORY: Keep only the last 20 messages to prevent "buffer full" (context window overflow)
      const recentHistory = history.slice(-20);
      
      let formattedHistory: any[] = [];
      let currentRole = "";
      let currentText = "";

      for (const msg of recentHistory) {
        const role = msg.sender === "user" ? "user" : "model";
        if (role === currentRole) {
          currentText += "\n" + msg.text;
        } else {
          if (currentRole !== "") {
            formattedHistory.push({ role: currentRole, parts: [{ text: currentText }] });
          }
          currentRole = role;
          currentText = msg.text;
        }
      }
      if (currentRole !== "") {
        formattedHistory.push({ role: currentRole, parts: [{ text: currentText }] });
      }

      if (formattedHistory.length > 0 && formattedHistory[0].role !== "user") {
        formattedHistory.shift();
      }

      chatSession = ai.chats.create({
        model: "gemini-3.1-flash-lite-preview",
        config: {
          systemInstruction,
          tools: [{
            functionDeclarations: [
              {
                name: "saveUserMemory",
                description: "Save a fact about the user to remember for future conversations.",
                parameters: {
                  type: Type.OBJECT,
                  properties: {
                    key: { type: Type.STRING, description: "The category or key of the memory (e.g., 'user_name', 'favorite_color')." },
                    value: { type: Type.STRING, description: "The fact to remember." }
                  },
                  required: ["key", "value"]
                }
              },
              {
                name: "executeBrowserAction",
                description: "Open a website or perform a search/message action on platforms like Google, YouTube, or WhatsApp. Use this when the user says 'search on Google', 'type in YouTube', or 'send a message on WhatsApp'.",
                parameters: {
                  type: Type.OBJECT,
                  properties: {
                    actionType: { type: Type.STRING, description: "Type of action: 'open', 'youtube', 'spotify', 'whatsapp', 'google'" },
                    query: { type: Type.STRING, description: "The search query, website name, or message content to 'type'." },
                    target: { type: Type.STRING, description: "The target phone number for WhatsApp, if applicable." }
                  },
                  required: ["actionType", "query"]
                }
              },
              {
                name: "typeIntoInput",
                description: "Type text into the user's input field. Use this when the user asks you to 'write this', 'type this', or 'put this in the box'.",
                parameters: {
                  type: Type.OBJECT,
                  properties: {
                    text: { type: Type.STRING, description: "The text to type into the input field." }
                  },
                  required: ["text"]
                }
              }
            ]
          }]
        },
        history: formattedHistory,
      });
    }

    const response = await chatSession.sendMessage({ message: prompt });
    
    // Handle potential function calls for memory saving
    if (response.functionCalls) {
      for (const call of response.functionCalls) {
        if (call.name === "saveUserMemory") {
          const { key, value } = call.args as any;
          await saveMemory(key, value);
          
          // Send tool response and get final text
          const result = await chatSession.sendMessage({
            message: {
              role: "user",
              parts: [{
                functionResponse: {
                  name: "saveUserMemory",
                  id: call.id,
                  response: { result: "Memory saved successfully." }
                }
              }]
            }
          });
          return result.text || "Theek hai, yaad rakhungi!";
        } else if (call.name === "executeBrowserAction") {
          const args = call.args as any;
          let url = "";
          if (args.actionType === "youtube") {
            url = `https://www.youtube.com/results?search_query=${encodeURIComponent(args.query)}`;
          } else if (args.actionType === "google") {
            url = `https://www.google.com/search?q=${encodeURIComponent(args.query)}`;
          } else if (args.actionType === "spotify") {
            url = `https://open.spotify.com/search/${encodeURIComponent(args.query)}`;
          } else if (args.actionType === "whatsapp") {
            url = `https://web.whatsapp.com/send?phone=${args.target || ''}&text=${encodeURIComponent(args.query)}`;
          } else {
            let website = args.query.replace(/\s+/g, "");
            if (!website.includes(".")) website += ".com";
            url = `https://www.${website}`;
          }
          return `[OPEN]:${url}`;
        } else if (call.name === "typeIntoInput") {
          const { text } = call.args as any;
          // We need a way to pass this back to the UI. 
          // Since geminiService is stateless, we'll return a special flag or just handle it in App.tsx
          // Actually, let's just return the text and a flag.
          // But getZoyaResponse returns a string.
          // I'll modify the return type to include optional metadata.
          return `[TYPE]:${text}`; 
        }
      }
    }

    return response.text || "Ugh, fine. I have nothing to say.";
  } catch (error: any) {
    console.error("Gemini Error:", error);
    const errMsg = error?.message?.toLowerCase() || "";
    if (errMsg.includes("quota") || errMsg.includes("exhausted")) {
      return "Uff, Google ne meri bolti band kar di hai (Quota Exceeded). Thodi der baad try karna, Sushant.";
    }
    if (errMsg.includes("network") || errMsg.includes("failed to fetch")) {
      return "Internet ka chakkar hai, Sushant! Connection check karo aur phir se try karo.";
    }
    return "Uff, mera dimaag kharab ho gaya hai. Try again later, Sushant.";
  }
}

export async function getZoyaAudio(text: string): Promise<string | null> {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: ["AUDIO"],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: "Kore" },
          },
        },
      },
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || null;
  } catch (error) {
    console.error("TTS Error:", error);
    return null;
  }
}

