export interface Memory {
  key: string;
  value: string;
}

export async function getMemories(): Promise<Memory[]> {
  try {
    const response = await fetch("/api/memories");
    if (!response.ok) throw new Error("Failed to fetch memories");
    return await response.json();
  } catch (error) {
    console.error("Memory Service Error:", error);
    return [];
  }
}

export async function saveMemory(key: string, value: string): Promise<boolean> {
  try {
    const response = await fetch("/api/memories", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key, value }),
    });
    return response.ok;
  } catch (error) {
    console.error("Memory Service Error:", error);
    return false;
  }
}

export async function deleteMemory(key: string): Promise<boolean> {
  try {
    const response = await fetch(`/api/memories/${key}`, {
      method: "DELETE",
    });
    return response.ok;
  } catch (error) {
    console.error("Memory Service Error:", error);
    return false;
  }
}

export function formatMemoriesForPrompt(memories: Memory[]): string {
  if (memories.length === 0) return "No specific memories stored yet.";
  return memories.map(m => `- ${m.key}: ${m.value}`).join("\n");
}
